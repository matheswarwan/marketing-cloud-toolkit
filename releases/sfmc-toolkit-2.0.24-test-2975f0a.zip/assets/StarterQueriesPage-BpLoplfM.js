import{K as e,M as t,Mt as n,P as r,c as i,d as a,dt as o,f as s,g as c,h as l,kt as u,l as d,nt as f,r as p,u as m}from"./createLucideIcon-C-_vCYzw.js";import{t as h}from"./copy-CYhXCHr_.js";import{r as g}from"./useToast-DW6_9DV6.js";import{Fn as _,Gs as v,Ho as y,Ms as b,Ro as x,Y as S}from"./app-8P8jaoRU.js";import{t as C}from"./useRouteSearch-D9prFBFG.js";import{t as w}from"./Input-BQed4uMk.js";var T=[`Sends and engagement`,`Bounces and deliverability`,`Subscribers and unsubscribes`,`Journeys`,`Lists`],E=[{id:`sends-by-job`,category:`Sends and engagement`,title:`Sends in the last 30 days with opens and clicks`,purpose:`One row per send (JobID): email name, when it went, how many were sent, unique opens and unique clicks.`,sql:`SELECT j.JobID, j.EmailName, j.DeliveredTime,
  COUNT(DISTINCT s.SubscriberKey) AS Sent,
  COUNT(DISTINCT o.SubscriberKey) AS UniqueOpens,
  COUNT(DISTINCT c.SubscriberKey) AS UniqueClicks
FROM _Job j
INNER JOIN _Sent s ON s.JobID = j.JobID
LEFT JOIN _Open o ON o.JobID = s.JobID AND o.SubscriberKey = s.SubscriberKey AND o.IsUnique = 1
LEFT JOIN _Click c ON c.JobID = s.JobID AND c.SubscriberKey = s.SubscriberKey AND c.IsUnique = 1
WHERE s.EventDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY j.JobID, j.EmailName, j.DeliveredTime`},{id:`opened-last-90`,category:`Sends and engagement`,title:`Subscribers who opened in the last 90 days`,purpose:`Engaged audience: everyone with at least one open in 90 days, with their latest open.`,sql:`SELECT o.SubscriberKey, MAX(o.EventDate) AS LastOpen, COUNT(*) AS Opens
FROM _Open o
WHERE o.EventDate >= DATEADD(DAY, -90, GETDATE())
GROUP BY o.SubscriberKey`},{id:`never-opened`,category:`Sends and engagement`,title:`Sent to in 90 days but never opened`,purpose:`Unengaged audience for a winback or a sunset policy.`,notes:`Apple Mail Privacy Protection opens images for its users, so some "opens" are not real; this list errs on the side of keeping people.`,sql:`SELECT s.SubscriberKey, COUNT(DISTINCT s.JobID) AS SendsReceived, MAX(s.EventDate) AS LastSent
FROM _Sent s
LEFT JOIN _Open o ON o.SubscriberKey = s.SubscriberKey AND o.EventDate >= DATEADD(DAY, -90, GETDATE())
WHERE s.EventDate >= DATEADD(DAY, -90, GETDATE())
  AND o.SubscriberKey IS NULL
GROUP BY s.SubscriberKey`},{id:`clicks-by-link`,category:`Sends and engagement`,title:`Clicks by link for one send`,purpose:`Which links were clicked in one send: change the JobID.`,sql:`SELECT c.URL, c.LinkName, COUNT(*) AS Clicks, COUNT(DISTINCT c.SubscriberKey) AS UniqueClickers
FROM _Click c
WHERE c.JobID = 12345
GROUP BY c.URL, c.LinkName`},{id:`top-domains`,category:`Sends and engagement`,title:`Opens and sends by email domain (30 days)`,purpose:`How each mailbox provider (gmail.com, outlook.com…) engages: a low open rate at one domain hints at a deliverability problem there.`,sql:`SELECT s.Domain,
  COUNT(DISTINCT s.SubscriberKey) AS Sent,
  COUNT(DISTINCT o.SubscriberKey) AS Opened
FROM _Sent s
LEFT JOIN _Open o ON o.JobID = s.JobID AND o.SubscriberKey = s.SubscriberKey
WHERE s.EventDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY s.Domain`},{id:`last-engagement`,category:`Sends and engagement`,title:`Last open and last click per subscriber`,purpose:`One row per subscriber with their latest open and click in the last 180 days, for scoring or suppression.`,sql:`SELECT s.SubscriberKey,
  MAX(o.EventDate) AS LastOpen,
  MAX(c.EventDate) AS LastClick
FROM _Sent s
LEFT JOIN _Open o ON o.SubscriberKey = s.SubscriberKey
LEFT JOIN _Click c ON c.SubscriberKey = s.SubscriberKey
WHERE s.EventDate >= DATEADD(DAY, -180, GETDATE())
GROUP BY s.SubscriberKey`},{id:`bounces-30`,category:`Bounces and deliverability`,title:`Bounces in the last 30 days with the reason`,purpose:`Every bounce with its category, type and the receiving server's SMTP reason.`,sql:`SELECT b.SubscriberKey, b.JobID, b.EventDate, b.BounceCategory, b.BounceType, b.SMTPCode, b.SMTPBounceReason
FROM _Bounce b
WHERE b.EventDate >= DATEADD(DAY, -30, GETDATE())`},{id:`bounce-reasons`,category:`Bounces and deliverability`,title:`Bounce reasons, most common first`,purpose:`How many bounces each category and SMTP code caused in 30 days: a spike in one code points at a block or a bad list.`,sql:`SELECT TOP 100 b.BounceCategory, b.SMTPCode, COUNT(*) AS Bounces
FROM _Bounce b
WHERE b.EventDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY b.BounceCategory, b.SMTPCode
ORDER BY COUNT(*) DESC`},{id:`hard-bounced`,category:`Bounces and deliverability`,title:`Hard bounces to suppress`,purpose:`Subscribers with a hard bounce in 90 days, with the latest one: candidates for a suppression or clean-up.`,sql:`SELECT b.SubscriberKey, MAX(b.EventDate) AS LastHardBounce, COUNT(*) AS HardBounces
FROM _Bounce b
WHERE b.BounceCategory = 'Hard bounce'
  AND b.EventDate >= DATEADD(DAY, -90, GETDATE())
GROUP BY b.SubscriberKey`},{id:`complaints`,category:`Bounces and deliverability`,title:`Spam complaints in the last 90 days`,purpose:`Who marked an email as spam, and which send: complaints hurt sender reputation fastest.`,sql:`SELECT c.SubscriberKey, c.JobID, c.EventDate, c.Domain
FROM _Complaint c
WHERE c.EventDate >= DATEADD(DAY, -90, GETDATE())`},{id:`held-subscribers`,category:`Bounces and deliverability`,title:`Held and bounced subscribers`,purpose:`Subscribers SFMC no longer sends to (held after repeated bounces) or that bounced lately.`,notes:`Data view _Subscribers is available in the enterprise (parent) business unit.`,sql:`SELECT s.SubscriberKey, s.EmailAddress, s.Status, s.BounceCount, s.DateUndeliverable
FROM _Subscribers s
WHERE s.Status IN ('held', 'bounced')`},{id:`unsubs-30`,category:`Subscribers and unsubscribes`,title:`Unsubscribes in the last 30 days and the send that caused them`,purpose:`Every unsubscribe with the email it came from.`,sql:`SELECT u.SubscriberKey, u.EventDate, u.JobID, j.EmailName
FROM _Unsubscribe u
LEFT JOIN _Job j ON j.JobID = u.JobID
WHERE u.EventDate >= DATEADD(DAY, -30, GETDATE())`},{id:`unsubs-by-email`,category:`Subscribers and unsubscribes`,title:`Unsubscribes per email (90 days)`,purpose:`Which emails make people leave.`,sql:`SELECT TOP 100 j.EmailName, COUNT(DISTINCT u.SubscriberKey) AS Unsubscribes
FROM _Unsubscribe u
INNER JOIN _Job j ON j.JobID = u.JobID
WHERE u.EventDate >= DATEADD(DAY, -90, GETDATE())
GROUP BY j.EmailName
ORDER BY COUNT(DISTINCT u.SubscriberKey) DESC`},{id:`bu-unsubs`,category:`Subscribers and unsubscribes`,title:`Business unit unsubscribes`,purpose:`People unsubscribed from a business unit only (not from everything), with the reason.`,sql:`SELECT b.SubscriberKey, b.BusinessUnitID, b.UnsubDateUTC, b.UnsubReason
FROM _BusinessUnitUnsubscribes b`},{id:`new-subscribers`,category:`Subscribers and unsubscribes`,title:`Subscribers who joined in the last 30 days`,purpose:`New people at All Subscribers.`,notes:`Data view _Subscribers is available in the enterprise (parent) business unit.`,sql:`SELECT s.SubscriberKey, s.EmailAddress, s.DateJoined, s.Status
FROM _Subscribers s
WHERE s.DateJoined >= DATEADD(DAY, -30, GETDATE())`},{id:`journey-email-sends`,category:`Journeys`,title:`Emails sent by journeys (30 days)`,purpose:`Sends per journey, version and email activity, joining tracking to journeys through the triggered send.`,sql:`SELECT j.JourneyName, j.VersionNumber, a.ActivityName,
  COUNT(DISTINCT s.SubscriberKey) AS Sent
FROM _Sent s
INNER JOIN _JourneyActivity a ON a.JourneyActivityObjectID = s.TriggererSendDefinitionObjectID
INNER JOIN _Journey j ON j.VersionID = a.VersionID
WHERE s.EventDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY j.JourneyName, j.VersionNumber, a.ActivityName`},{id:`journey-email-engagement`,category:`Journeys`,title:`Opens and clicks per journey email (30 days)`,purpose:`Unique opens and clicks for each email activity in each journey version.`,sql:`SELECT j.JourneyName, j.VersionNumber, a.ActivityName,
  COUNT(DISTINCT s.SubscriberKey) AS Sent,
  COUNT(DISTINCT o.SubscriberKey) AS UniqueOpens,
  COUNT(DISTINCT c.SubscriberKey) AS UniqueClicks
FROM _Sent s
INNER JOIN _JourneyActivity a ON a.JourneyActivityObjectID = s.TriggererSendDefinitionObjectID
INNER JOIN _Journey j ON j.VersionID = a.VersionID
LEFT JOIN _Open o ON o.JobID = s.JobID AND o.SubscriberKey = s.SubscriberKey
LEFT JOIN _Click c ON c.JobID = s.JobID AND c.SubscriberKey = s.SubscriberKey
WHERE s.EventDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY j.JourneyName, j.VersionNumber, a.ActivityName`},{id:`running-journeys`,category:`Journeys`,title:`Journeys and their latest version`,purpose:`Every journey version with its status and when it was last published.`,sql:`SELECT j.JourneyName, j.VersionNumber, j.JourneyStatus, j.LastPublishedDate, j.ModifiedDate
FROM _Journey j`},{id:`list-members`,category:`Lists`,title:`Members of one list with their status`,purpose:`Who is on a list and whether they are active or unsubscribed: change the list name.`,sql:`SELECT l.SubscriberKey, l.EmailAddress, l.Status, l.CreatedDate, l.DateUnsubscribed
FROM _ListSubscribers l
WHERE l.ListName = 'My List'`},{id:`list-sizes`,category:`Lists`,title:`List sizes by status`,purpose:`How many active, unsubscribed, held and bounced members each list has.`,sql:`SELECT l.ListName, l.Status, COUNT(*) AS Members
FROM _ListSubscribers l
GROUP BY l.ListName, l.Status`}],D={class:`p-4 space-y-4 max-w-5xl`},O={class:`flex flex-wrap items-center gap-2`},k={class:`relative flex-1 min-w-[220px] max-w-md`},A={class:`flex flex-wrap gap-1.5`,role:`group`,"aria-label":`Category`},j=[`aria-pressed`,`onClick`],M={key:0,class:`text-sm text-muted-foreground`},N={class:`text-sm font-semibold`},P={class:`font-normal text-muted-foreground`},F=[`data-starter`],I={class:`flex flex-wrap items-start gap-2`},L={class:`flex-1 min-w-0`},R={class:`text-sm font-semibold`},z={class:`text-xs text-muted-foreground`},B={key:0,class:`text-xs text-amber-700 dark:text-amber-300 mt-0.5`},V={__name:`StarterQueriesPage`,setup(V){let H=v(),U=f(``),W=f(``),G=f(``);C(`/queries/starter`,e=>{U.value=e,W.value=``});let K=i(()=>{let e=U.value.toLowerCase().split(/\s+/).filter(Boolean);return E.filter(t=>(!W.value||t.category===W.value)&&e.every(e=>`${t.title} ${t.purpose} ${t.notes||``} ${t.sql}`.toLowerCase().includes(e)))}),q=i(()=>T.map(e=>({name:e,items:K.value.filter(t=>t.category===e)})).filter(e=>e.items.length));function J(e){H.push({path:`/queries/workspace`,query:{sql:e.sql}})}async function Y(e){try{await navigator.clipboard.writeText(e.sql),G.value=e.id,setTimeout(()=>{G.value===e.id&&(G.value=``)},1500)}catch{g(`Could not copy. Select the SQL and copy it instead.`)}}return(i,f)=>(t(),s(`div`,D,[f[2]||=d(`div`,{class:`flex flex-wrap items-center gap-2`},[d(`h1`,{class:`text-lg font-semibold`},`Starter queries`),d(`span`,{class:`text-xs text-muted-foreground`},`Ready-made SQL over SFMC's data views. Open one in Run Query, change the dates or names, and run it. Data views keep about six months of tracking.`)],-1),d(`div`,O,[d(`div`,k,[c(o(x),{class:`h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground`}),c(w,{modelValue:U.value,"onUpdate:modelValue":f[0]||=e=>U.value=e,class:`pl-9 rounded-full`,placeholder:`Search: bounces, journey, unsubscribe…`,"aria-label":`Search starter queries`},null,8,[`modelValue`])]),d(`div`,A,[(t(!0),s(p,null,r([``,...o(T)],e=>(t(),s(`button`,{key:e,type:`button`,class:u([`h-7 px-3 rounded-full border text-xs`,W.value===e?`bg-primary text-primary-foreground border-primary`:`border-border hover:bg-accent`]),"aria-pressed":W.value===e,onClick:t=>W.value=e},n(e||`All`),11,j))),128))])]),q.value.length?a(``,!0):(t(),s(`p`,M,`No starter query matches.`)),(t(!0),s(p,null,r(q.value,i=>(t(),s(`section`,{key:i.name,class:`space-y-2`},[d(`h2`,N,[l(n(i.name)+` `,1),d(`span`,P,`(`+n(i.items.length)+`)`,1)]),(t(!0),s(p,null,r(i.items,r=>(t(),s(`article`,{key:r.id,class:`rounded-lg border border-border bg-card p-3 space-y-2`,"data-starter":r.id},[d(`div`,I,[d(`div`,L,[d(`div`,R,n(r.title),1),d(`div`,z,n(r.purpose),1),r.notes?(t(),s(`div`,B,n(r.notes),1)):a(``,!0)]),c(_,{size:`sm`,class:`gap-1`,"data-starter-open":``,onClick:e=>J(r)},{default:e(()=>[c(o(y),{class:`h-3.5 w-3.5`}),f[1]||=l(` Open in Run Query`,-1)]),_:1},8,[`onClick`]),c(_,{size:`sm`,variant:`outline`,class:`gap-1`,"aria-label":`Copy the SQL of ${r.title}`,onClick:e=>Y(r)},{default:e(()=>[G.value===r.id?(t(),m(o(b),{key:0,class:`h-3.5 w-3.5`})):(t(),m(o(h),{key:1,class:`h-3.5 w-3.5`})),l(` `+n(G.value===r.id?`Copied`:`Copy`),1)]),_:2},1032,[`aria-label`,`onClick`])]),c(S,{code:r.sql,lang:`sql`,"max-height":`220px`},null,8,[`code`])],8,F))),128))]))),128))]))}};export{V as default};